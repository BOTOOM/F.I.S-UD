package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public class FabricaDeSoftware extends AFabricaDeBien {

	@Override
	public AProducto crearProducto() {
		return new Software();
	}
	@Override
	public AServicio crearServicio() {
		return new Capacitacion();
	}

}
