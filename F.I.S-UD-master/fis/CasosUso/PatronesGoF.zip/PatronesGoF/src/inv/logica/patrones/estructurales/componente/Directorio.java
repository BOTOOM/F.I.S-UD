package inv.logica.patrones.estructurales.componente;

import java.util.ArrayList;
import java.util.List;

/** @author Sandro Bola�os */

public class Directorio extends AArchivo {
    List<AArchivo> archivos=new ArrayList<AArchivo>();
	public Directorio(String nombre, int tama�o) {
		super(nombre, tama�o);		
	}
	public void adicionar(AArchivo archivo){
		if(archivo!=null){
		   archivos.add(archivo);
		}
	}	
	@Override
	public void listar() {
		System.out.print("directorio ");
		for(AArchivo archivo_i:archivos){			
			tama�o+=archivo_i.getTama�o();
		}
		super.listar();
		for(AArchivo archivo_i:archivos){
			archivo_i.listar();			
		}
	}
	@Override
	public int getTama�o() {
		int tama�o=0;
		for(AArchivo archivo_i:archivos){			
			tama�o+=archivo_i.getTama�o();
		}
		return tama�o;
	}
}
