package inv.logica.patrones.creacionales.prototipo;

/** @author Sandro Bola�os */

public class Ciudadano {
       ICopia copia;
       public void hacerCapias(){
    	     Cedula nit = new Cedula();
    	     nit.setNumero(123456789);
    	     nit.setNombre("Sandro");    	     
    	     Cedula copiaDeLaCedula = (Cedula)nit.copiar();
    	     System.out.println("nombre: "+copiaDeLaCedula.nombre+"\ncc....: "+copiaDeLaCedula.numero);
       }
}
