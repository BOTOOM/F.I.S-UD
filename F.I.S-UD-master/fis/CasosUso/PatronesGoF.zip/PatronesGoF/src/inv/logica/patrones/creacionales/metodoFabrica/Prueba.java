package inv.logica.patrones.creacionales.metodoFabrica;

/** @author Sandro Bola�os */

public class Prueba {
	public void probar() {
		new MarcoDeSecuencia().crearMarco();
	}
	public static void main(String[] args) {
		new Prueba().probar();
	}
}
