package inv.logica.patrones.creacionales.constructor;

/** @author Sandro Bola�os */

public class TiendaFormal extends ATienda<String> {
	    String traje="";
		@Override
		public void vendeCalzado() {
			traje+="mocas�n ";
			System.out.println("mocas�n");
		}
		@Override
		public void vendeAjuar() {
			traje+="pantalon camisa saco ";
			System.out.println("pantalon camisa saco ");
		}
		@Override
		public void vendeAccesorios() {
			traje+="correa corbata pa�uelo";
			System.out.println("correa corbata pa�uelo");
		}
		public String getTraje(){
			return traje;
		}	
}
