package inv.logica.patrones.comportamiento.estrategia;

/** @author Sandro Bola�os */

public interface IAcceso {
       void acceder();
}
