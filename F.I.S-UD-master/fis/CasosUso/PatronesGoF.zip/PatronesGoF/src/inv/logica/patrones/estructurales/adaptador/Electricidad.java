package inv.logica.patrones.estructurales.adaptador;

/** @author Sandro Bola�os */

public class Electricidad {
	int voltaje;
	public Electricidad(int voltaje) {		
		this.voltaje = voltaje;
	}
	public void electoructar() {
		if(voltaje>=500){
		   System.out.println("electrocutar");
		}
	}
}
