package inv.logica.patrones.estructurales.puente;

/** @author Sandro Bola�os */

public class Voceador implements IPublicidad {
	@Override
	public void anunciarMenu() {
		System.out.println("vocear el menu");
	}
}
