package inv.logica.patrones.estructurales.decorador;

/** @author Sandro Bola�os */

public abstract class ARecursoLiterario extends ATexto {
	
	ATexto escrito;

	public ARecursoLiterario(ATexto escrito, String texto) {
		super(texto);
		this.escrito = escrito;
	}

	@Override
	public void expresar() {
		System.out.println(escrito.getTexto());
	}

}
