package inv.logica.patrones.comportamiento.comando;

/** @author Sandro Bola�os */

public interface IComando {
	void ejecutar();
}
