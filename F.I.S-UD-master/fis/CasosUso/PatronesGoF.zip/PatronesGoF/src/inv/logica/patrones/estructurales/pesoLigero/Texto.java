package inv.logica.patrones.estructurales.pesoLigero;

/** @author Sandro Bola�os */

public class Texto implements IPresentable {
	String texto;
		
	public Texto(String texto) {		
		this.texto = texto;
	}
	
	@Override
	public void presentar(Object gc, int x, int y) {
		// Presentar imagen
	}
	
}
