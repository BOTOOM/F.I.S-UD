package inv.logica.patrones.comportamiento.iterador;

/** @author Sandro Bola�os */

public interface IAgregado<T>{
       IIterador<T> crearIterador();
}
