package inv.logica.patrones.estructurales.puente;

/** @author Sandro Bola�os */

public interface IPublicidad {
	void anunciarMenu();
}
