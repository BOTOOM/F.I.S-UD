package inv.logica.patrones.comportamiento.momento;

/** @author Sandro Bola�os */

public class Persona {
	int numeroDeA�os;
	String etapaDeLaVida;
	String nombre;
	public Persona(int numeroDeA�os, String etapaDeLaVida, String nombre) {		
		this.numeroDeA�os = numeroDeA�os;
		this.etapaDeLaVida = etapaDeLaVida;
		this.nombre = nombre;
	}
	public Edad getEdad(){
		return new Edad(numeroDeA�os,etapaDeLaVida);
	}
	public void setEdad(Edad edad){
		numeroDeA�os = edad.getNumeroDeA�os();
		etapaDeLaVida = edad.getEtapaDeLaVida();
	}
}
