package inv.logica.patrones.comportamiento.observador;

/** @author Sandro Bola�os */

public interface IMedico {
       void observar();
}
