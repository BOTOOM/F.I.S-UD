package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public class FabricaDeMuebles extends AFabricaDeBien {

	@Override
	public AProducto crearProducto() {
		return new Mueble();
	}
	@Override
	public AServicio crearServicio() {
		return new Restauracion();
	}

}
