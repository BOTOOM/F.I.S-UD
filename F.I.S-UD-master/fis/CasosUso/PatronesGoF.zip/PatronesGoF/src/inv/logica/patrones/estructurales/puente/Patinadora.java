package inv.logica.patrones.estructurales.puente;

/** @author Sandro Bola�os */

public class Patinadora implements IPublicidad {

	@Override
	public void anunciarMenu() {
		System.out.println("entregar el volante");

	}

}
