package inv.logica.patrones.estructurales.pesoLigero;

/** @author Sandro Bola�os */

public interface IPresentable {
	void presentar(Object gc, int x, int y);
}
