package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public class Mueble extends AProducto {

}
