package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public class Software extends AProducto {

}
