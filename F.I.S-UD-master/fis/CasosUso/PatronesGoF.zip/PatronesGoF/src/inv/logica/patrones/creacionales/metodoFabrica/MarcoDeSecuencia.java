package inv.logica.patrones.creacionales.metodoFabrica;

/** @author Sandro Bola�os */

public class MarcoDeSecuencia extends AMarcoGrafico {
	@Override
	protected ADiagramaDeUml montarBarraDeHerramientas() {
		return new DiagramaDeSecuencia();
	}
}
