package inv.logica.patrones.estructurales.componente;

/** @author Sandro Bola�os */

public abstract class AArchivo {
	String nombre;
	int tama�o;
	public int getTama�o() {return tama�o;}
		public AArchivo(String nombre, int tama�o) {
		super();
		this.nombre = nombre;
		this.tama�o = tama�o;
	}
	public void listar() {
		System.out.println("nombre:" + nombre + " tama�o:" + tama�o);
	}
}
