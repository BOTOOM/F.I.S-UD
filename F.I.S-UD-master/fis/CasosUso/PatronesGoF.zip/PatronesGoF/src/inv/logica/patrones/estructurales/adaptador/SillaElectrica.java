package inv.logica.patrones.estructurales.adaptador;

/** @author Sandro Bola�os */

public class SillaElectrica implements ISilla {
    Electricidad voltage;
	public SillaElectrica(Electricidad voltage) {		
		this.voltage = voltage;
	}
	@Override
	public void acomodar() {
		System.out.println("acomodar");
		voltage.electoructar();
	}
}
