package inv.logica.patrones.creacionales.singleton;

import static java.lang.Math.cos;
import static java.lang.Math.sin;

/** @author Sandro Bola�os */

public class Calculadora {
	private static Calculadora calculadora;
	private Calculadora() {}
	private static void crearLaCalculadora() {
		calculadora = new Calculadora();
	}
	private static boolean noExisteUnaCalculadora() {
		return calculadora == null;
	}
	public static Calculadora getCalculadora() {
		if (noExisteUnaCalculadora()) {
			crearLaCalculadora();
		}
		return calculadora;
	}
	public int sumar(int a,int b){
		return a+b;
	} 
	public int restar(int a,int b){
		return a-b;
	}
	public double seno(double angulo){
		return sin(angulo);
	}
	public double coseno(double angulo){
		return cos(angulo);
	}
}
