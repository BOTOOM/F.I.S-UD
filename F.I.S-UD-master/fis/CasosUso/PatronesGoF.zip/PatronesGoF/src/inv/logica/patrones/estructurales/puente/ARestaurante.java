package inv.logica.patrones.estructurales.puente;

/** @author Sandro Bola�os */

public abstract class ARestaurante {
	IPublicidad publicidad;
	public void setPublicidad(IPublicidad publicidad) {
		this.publicidad = publicidad;
	}
	public void ofrecerMenu() {
		publicidad.anunciarMenu();
	}
}
