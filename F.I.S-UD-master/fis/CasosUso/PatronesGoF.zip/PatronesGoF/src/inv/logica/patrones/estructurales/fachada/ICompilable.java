package inv.logica.patrones.estructurales.fachada;

/** @author Sandro Bola�os */

public interface ICompilable {
	void compilar();
}
