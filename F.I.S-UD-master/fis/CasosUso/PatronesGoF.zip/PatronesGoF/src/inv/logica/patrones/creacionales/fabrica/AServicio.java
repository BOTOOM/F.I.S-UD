package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public abstract class AServicio extends ABien{
	
}
