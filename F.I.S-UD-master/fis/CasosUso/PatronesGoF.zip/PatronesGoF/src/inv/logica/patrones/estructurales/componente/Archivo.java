package inv.logica.patrones.estructurales.componente;

/** @author Sandro Bola�os */

public class Archivo extends AArchivo{
	public Archivo(String nombre, int tama�o) {
		super(nombre, tama�o);
	}

	@Override
	public void listar() {
		System.out.print("Archivo ");
		super.listar();
	}
	
}
