package inv.logica.patrones.creacionales.singleton;

/** @author Sandro Bola�os */

public class Prueba {
	public void probar() {
		Calculadora c1=Calculadora.getCalculadora();
		Calculadora c2=Calculadora.getCalculadora();
		System.out.println(c1.sumar(1, 1)+" "+c2.restar(2, 4));
	}
	public static void main(String[] args) {
		new Prueba().probar();
	}
}
