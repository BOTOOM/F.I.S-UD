package inv.logica.patrones.comportamiento.visitador;

/** @author Sandro Bola�os */

public interface ISitio {
       void aceptar(Visitador turista);
}
