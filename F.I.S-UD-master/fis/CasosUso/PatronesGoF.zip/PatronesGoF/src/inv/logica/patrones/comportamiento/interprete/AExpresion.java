package inv.logica.patrones.comportamiento.interprete;

/** @author Sandro Bola�os */

public abstract class AExpresion {
	public abstract boolean evaluar(Situacion situacion);
}
