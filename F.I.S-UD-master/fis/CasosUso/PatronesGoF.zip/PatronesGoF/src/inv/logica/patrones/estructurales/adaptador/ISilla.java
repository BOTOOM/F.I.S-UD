package inv.logica.patrones.estructurales.adaptador;

/** @author Sandro Bola�os */

public interface ISilla {
       void acomodar();
}
