package inv.logica.patrones.creacionales.constructor;

/** @author Sandro Bola�os */

public class Prueba {
	public void probar() {
		Comprador sandro = new Comprador();

		sandro.setTienda(new TiendaDeportiva());
		sandro.comprarTraje();

		sandro.setTienda(new TiendaFormal());
		sandro.comprarTraje();
	}

	public static void main(String[] args) {
		new Prueba().probar();
	}

}
