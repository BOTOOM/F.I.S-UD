package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public class Prueba {
	public void probar() {
		Organizacion colosoft = new Organizacion();
    	colosoft.setFabrica(new FabricaDeSoftware());
    	colosoft.cargarBien();
    	
    	Organizacion muebles =new Organizacion();
    	muebles.setFabrica(new FabricaDeMuebles());
    	muebles.cargarBien();
	}

	public static void main(String[] args) {
		new Prueba().probar();
	}

}
