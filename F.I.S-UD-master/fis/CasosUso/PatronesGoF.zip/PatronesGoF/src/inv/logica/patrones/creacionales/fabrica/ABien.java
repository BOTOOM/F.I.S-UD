package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public abstract class ABien {
	public ABien() {
		System.out.println("creando un "+getClass().getSimpleName());
	}
}
