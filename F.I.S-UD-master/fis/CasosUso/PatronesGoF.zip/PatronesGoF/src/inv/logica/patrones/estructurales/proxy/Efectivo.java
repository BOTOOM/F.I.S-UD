package inv.logica.patrones.estructurales.proxy;

/** @author Sandro Bola�os */

public class Efectivo extends APago {
	private int valor;
	public Efectivo(int valor) {		
		this.valor = valor;
	}
	@Override
	public int pagar() {
		return valor;
	}
}
