package inv.logica.patrones.creacionales.prototipo;

/** @author Sandro Bola�os */

public interface ICopia {
       Object copiar();
}
