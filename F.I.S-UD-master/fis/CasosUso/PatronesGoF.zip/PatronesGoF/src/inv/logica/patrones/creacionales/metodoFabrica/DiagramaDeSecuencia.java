package inv.logica.patrones.creacionales.metodoFabrica;

/** @author Sandro Bola�os */

public class DiagramaDeSecuencia extends ADiagramaDeUml {
	public DiagramaDeSecuencia() {
		System.out.println("creando un diagrama de secuencia");
	}
}
