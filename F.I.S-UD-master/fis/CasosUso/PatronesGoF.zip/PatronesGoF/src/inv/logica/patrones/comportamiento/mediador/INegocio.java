package inv.logica.patrones.comportamiento.mediador;

/** @author Sandro Bola�os */

public interface INegocio {
       void proponerOfertas(ANegociador negociado);
}
