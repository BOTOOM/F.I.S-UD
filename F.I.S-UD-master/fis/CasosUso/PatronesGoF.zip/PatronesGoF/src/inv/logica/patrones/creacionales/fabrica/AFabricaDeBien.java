package inv.logica.patrones.creacionales.fabrica;

/** @author Sandro Bola�os */

public abstract class AFabricaDeBien {
       public abstract AProducto crearProducto();
       public abstract AServicio crearServicio();
}
