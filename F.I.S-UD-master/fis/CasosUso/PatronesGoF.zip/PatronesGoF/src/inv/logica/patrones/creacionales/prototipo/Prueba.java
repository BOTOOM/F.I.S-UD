package inv.logica.patrones.creacionales.prototipo;

/** @author Sandro Bola�os */

public class Prueba {
	public void probar() {
		new Ciudadano().hacerCapias();
	}
	public static void main(String[] args) {
		new Prueba().probar();
	}
}
