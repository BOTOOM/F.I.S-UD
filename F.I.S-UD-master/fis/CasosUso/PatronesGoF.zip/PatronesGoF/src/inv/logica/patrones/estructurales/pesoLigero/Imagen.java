package inv.logica.patrones.estructurales.pesoLigero;

import javax.swing.ImageIcon;

/** @author Sandro Bola�os */

public class Imagen implements IPresentable {
	String ruta;
	ImageIcon imagen;
	
	public Imagen(String ruta) {
		super();
		this.ruta = ruta;
		imagen = new ImageIcon(ruta);
	}
	
	@Override
	public void presentar(Object gc, int x, int y) {
		System.out.println("Presentar imagen "+ruta+" en x:"+x+" y:"+y);
	}
	
}
