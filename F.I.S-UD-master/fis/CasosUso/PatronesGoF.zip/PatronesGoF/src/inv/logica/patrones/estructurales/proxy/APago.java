package inv.logica.patrones.estructurales.proxy;

/** @author Sandro Bola�os */

public abstract class APago {
	public abstract int pagar();
}
