package inv.logica.patrones.estructurales.adaptador;

/** @author Sandro Bola�os */

public class Condenado {
	ISilla silla;
	public Condenado(ISilla silla) {		
		this.silla = silla;
		silla.acomodar();
	}
}
