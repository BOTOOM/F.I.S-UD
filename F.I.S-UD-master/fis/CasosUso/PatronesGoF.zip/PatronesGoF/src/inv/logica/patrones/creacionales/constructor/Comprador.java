package inv.logica.patrones.creacionales.constructor;

/** @author Sandro Bola�os */

public class Comprador {
	     ATienda<String> tienda;
         public ATienda<String> getTienda() {
			return tienda;
		}
		public void setTienda(ATienda<String> tienda) {
			this.tienda = tienda;
		}
		public void comprarTraje(){
        	   tienda.vendeAccesorios();
        	   tienda.vendeCalzado();
        	   tienda.vendeAjuar();
        	   System.out.println(tienda.getTraje());
        	 
         }
}
