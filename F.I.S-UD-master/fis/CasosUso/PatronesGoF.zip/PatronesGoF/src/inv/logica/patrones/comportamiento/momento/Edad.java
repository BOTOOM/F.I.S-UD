package inv.logica.patrones.comportamiento.momento;

/** @author Sandro Bola�os */

public class Edad {
    int numeroDeA�os;
    String etapaDeLaVida;
	public Edad(int numeroDeA�os, String etapaDeLaVida) {		
		this.numeroDeA�os = numeroDeA�os;
		this.etapaDeLaVida = etapaDeLaVida;
	}
	public int getNumeroDeA�os() {
		return numeroDeA�os;
	}
	public void setNumeroDeA�os(int numeroDeA�os) {
		this.numeroDeA�os = numeroDeA�os;
	}
	public String getEtapaDeLaVida() {
		return etapaDeLaVida;
	}
	public void setEtapaDeLaVida(String etapaDeLaVida) {
		this.etapaDeLaVida = etapaDeLaVida;
	}      
}
