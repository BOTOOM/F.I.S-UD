package inv.logica.patrones.estructurales.puente;

/** @author Sandro Bola�os */

public class RestauranteTipico extends ARestaurante {

}
