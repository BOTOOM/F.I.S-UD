package inv.logica.patrones.creacionales.metodoFabrica;

/** @author Sandro Bola�os */

public abstract class ADiagramaDeUml {

}
