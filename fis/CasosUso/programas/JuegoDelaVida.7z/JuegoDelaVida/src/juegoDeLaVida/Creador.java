package juegoDeLaVida;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;

public class Creador {
	public static Display display=Display.getDefault();
	public static int MARGEN = 9;
	public static Rectangle MUNDO = new Rectangle(20,20,200,200);	
	public static Color colorNatural= display.getSystemColor(SWT.COLOR_GREEN);
	public static Color colorVida= display.getSystemColor(SWT.COLOR_BLUE);
	public static GC PalabraDeDios;
	//////////////////////////////////////////////////////////////////////////
	private Shell s;	
	private Naturaleza natura;	
	//////////////////////////////////////////////////////////////////////////
	private Button hayaLuz(String cad,int pos) {
		Button b=new Button(s,SWT.FLAT);		
		b.setBounds(MUNDO.x+MUNDO.width/2+pos, MUNDO.y+MUNDO.height+MARGEN,50,22);
		b.setText(cad);
		return b;
	}
	private void origen() {(natura = new Naturaleza(MUNDO)).inicio();}
	private void cambio() {natura.cambio();}
	private void enUnPrincipio() {		
		s = new Shell(display,SWT.CLOSE | SWT.PRIMARY_MODAL);
		s.setLayout(null);
		s.setBounds(0,0,2*MUNDO.x+MUNDO.width+2*MARGEN, 2*MUNDO.y+MUNDO.height+6*MARGEN);				
		hayaLuz("origen",-60).addListener(SWT.MouseDown,(Event)->{origen();});
		hayaLuz("cambio",+10).addListener(SWT.MouseDown,(Event)->{cambio();}); 
		s.open(); 
	}  
	private void creando(Event e) {
		int x=e.x-e.x%Organismo.TAMANO;
		int y=e.y-e.y%Organismo.TAMANO;
		if(MUNDO.contains(x, y)) {			   
		   natura.setOrganismo(new Organismo(natura,x,y));
		   natura.inicio();   
		}  
	}
	private void crear() { 
		PalabraDeDios = new GC(s);
		natura = new Naturaleza(MUNDO);		
		s.addListener(SWT.MouseDown,(Event e)->{creando(e);});	
		s.addListener(SWT.Paint,(Event e)->{natura.inicio();});	
	}
	private void iniciar() {
		while (!s.isDisposed()) {
		      if (!display.readAndDispatch()) {
			      display.sleep();
		      }		     
	    }  	
	    display.dispose();	
	    PalabraDeDios.dispose();	   
	}
	public void creacion() {
		enUnPrincipio();		
		crear();
		iniciar();
	}
	public static void main(String[] args) {		
		new Creador().creacion();		
	}
}
