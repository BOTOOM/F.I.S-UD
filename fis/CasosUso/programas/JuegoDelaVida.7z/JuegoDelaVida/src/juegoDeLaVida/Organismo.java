package juegoDeLaVida;

import static juegoDeLaVida.Creador.*;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class Organismo{
	public static int TAMANO = 10;
	public enum Ciclo{NADA,NACE,VIVE,MUERE};
	Ciclo ciclo;	        
	Rectangle cuerpo;  
	int x,y;
	Naturaleza ambiente; 
	
	public Organismo(Naturaleza ambiente,int x, int y,boolean nada) {		
		this.cuerpo = new Rectangle(MUNDO.x+x*TAMANO,MUNDO.y+y*TAMANO,TAMANO,TAMANO);
		ciclo = nada?Ciclo.NADA:Ciclo.NACE;
		this.x=x;
		this.y=y;
		this.ambiente = ambiente;
	}
	public Organismo(Naturaleza ambiente,int x, int y) {		
		this.cuerpo = new Rectangle(x,y,TAMANO,TAMANO);
		ciclo = Ciclo.VIVE;
		this.ambiente = ambiente;
	}
	public Point getOrigen() {
		x = cuerpo.x/TAMANO-2;
		y = cuerpo.y/TAMANO-2;
		return new Point(x,y);
	}
	public void dibujar() {
		PalabraDeDios.setBackground(Creador.colorVida);
		PalabraDeDios.fillOval(cuerpo.x,cuerpo.y,cuerpo.width,cuerpo.height);
	}
	private boolean hayVecino(int x,int y) {
		Organismo org = null;
		if((x>=0&&x<ambiente.tx)&&(y>=0&&y<ambiente.ty)){
		   org = ambiente.actualGeneracion[x][y];
		}
		return org!=null;
	}
	private int verVecindad() {		
		int n=0;
		n+=hayVecino(x-1,y-1)?1:0;
		n+=hayVecino(x-0,y-1)?1:0;
		n+=hayVecino(x+1,y-1)?1:0;		
		n+=hayVecino(x-1,y  )?1:0;
		n+=hayVecino(x+1,y  )?1:0;		
		n+=hayVecino(x-1,y+1)?1:0;
		n+=hayVecino(x-0,y+1)?1:0;
		n+=hayVecino(x+1,y+1)?1:0;
		return n;
	}
	private void nace() {
		ciclo=Ciclo.NACE;				
	}
	public Organismo vive() {
		ciclo=Ciclo.VIVE;
		return this;
	}
	private void muere() {
		ciclo=Ciclo.MUERE;	
	}
	public void existir(){
		int vecinas = verVecindad();
		if(ciclo == Ciclo.NADA) {
		   if(vecinas==3) {
			  nace();
		   }
		}else if(ciclo == Ciclo.VIVE) {
			if(vecinas == 2 || vecinas == 3) {
			   vive();
			}else {
			   muere();
			}
		}
	}
	public boolean estaVivo() {
		return ciclo==Ciclo.VIVE;
	}
	public boolean nacio() {
		return ciclo==Ciclo.NACE;
	}
}
