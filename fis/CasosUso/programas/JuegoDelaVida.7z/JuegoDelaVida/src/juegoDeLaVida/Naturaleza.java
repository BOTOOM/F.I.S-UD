package juegoDeLaVida;

import static juegoDeLaVida.Creador.PalabraDeDios;
import static juegoDeLaVida.Creador.colorNatural;

import org.eclipse.swt.graphics.Rectangle;

public class Naturaleza {  
	Organismo[][] actualGeneracion;
    Organismo[][] nuevaGeneracion;
    int tx,ty;
	public Naturaleza(Rectangle mundo) {		
		this.tx = mundo.width/Organismo.TAMANO;
		this.ty = mundo.height/Organismo.TAMANO;
		this.actualGeneracion = new Organismo[tx][ty];		
		inicio();
	}
	public void setOrganismo(Organismo org) {
		if(actualGeneracion[org.getOrigen().x][org.getOrigen().y]!=null){
		   actualGeneracion[org.getOrigen().x][org.getOrigen().y]=null;
		}else {
		   actualGeneracion[org.getOrigen().x][org.getOrigen().y]=org;
		}
	}
	public void inicio() {
		PalabraDeDios.setBackground(colorNatural);
		PalabraDeDios.fillRectangle(Creador.MUNDO);
		for(int i=0;i<tx;i++) {
    		for(int j=0;j<ty;j++) {
    			/////////////////
    			if(actualGeneracion[i][j]!=null) {
    			   actualGeneracion[i][j].dibujar();
    			}
    		}
		}
	}
	private void evolucionar() {
		for(int i=0;i<tx;i++) {
    		for(int j=0;j<ty;j++) {
    			/////////////////
    			if(actualGeneracion[i][j]!=null) {
    			   actualGeneracion[i][j].existir();
    			   if(actualGeneracion[i][j].estaVivo()){
    				  nuevaGeneracion[i][j]=actualGeneracion[i][j];
    			   }
    			}else {
    				Organismo org=new Organismo(this,i,j,true);
      			    org.existir();
    				if(org.nacio()){
    				   nuevaGeneracion[i][j]=org.vive();
    			    }
    			}
    			
    		}
    	}
	}
    public void cambio() { 
    	nuevaGeneracion = new Organismo[tx][ty];
    	evolucionar();
    	actualGeneracion = nuevaGeneracion;
    	inicio();    		
    }
}
